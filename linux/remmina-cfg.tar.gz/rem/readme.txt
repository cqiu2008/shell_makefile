//S1:copy the common.remmina to the destination folder ~/.remmina 
cp -rf common.remmina ~/.remmina
//S2:Modify the common.remmina
sudo gvim common.remmina
name=xxx
server=xxx
username=xxx
//S3:modify the common.remmina to the new name
cp -rf common.remmina 151xx.remmina
